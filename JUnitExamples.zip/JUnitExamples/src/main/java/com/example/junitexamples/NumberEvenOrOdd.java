package com.example.junitexamples;

public class NumberEvenOrOdd {

    public static String checkNumberParity(int number) {
        if (number % 2 == 0) {
            return "Even";
        } else {
            return "Oneven";
        }
    }
}


